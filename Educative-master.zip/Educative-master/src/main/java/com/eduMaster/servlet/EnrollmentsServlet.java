package com.eduMaster.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.catalina.User;

import com.eduMaster.core.enrollment;
import com.eduMaster.core.usersDao;
 
 
import com.eduMaster.db.DatabaseConfig;
import com.eduMaster.db.MySqlDatabaseConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/enrollments")
public class EnrollmentsServlet extends HttpServlet {
    private Connection connection;
    private usersDao userDao;

    public EnrollmentsServlet() {
        DatabaseConfig config = new DatabaseConfig("jdbc:mysql://localhost:3306/eduMaster", "username", "password");
        try {
			connection = new MySqlDatabaseConnection(config).getConnection(config);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        userDao = new usersDao();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = Integer.parseInt(request.getParameter("user_id"));
        int courseId = Integer.parseInt(request.getParameter("course_id"));

        User user = usersDao.getuserById(userId);
       enrollment enrollment = new enrollment(userId, courseId);

        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO enrollments (user_id, course_id) VALUES (?, ?)");
            statement.setInt(1, userId);
            statement.setInt(2, courseId);
            statement.executeUpdate();

            // Add the enrollment to the user's profile
            (( users) user).addenrollment(enrollment);
            userDao.updateusers(user);

            response.sendRedirect("user_profile.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error while enrolling in the course.");
        }
    }
}