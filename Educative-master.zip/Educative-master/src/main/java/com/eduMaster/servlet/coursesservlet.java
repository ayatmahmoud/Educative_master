 package com.eduMaster.servlet; 
 
import java.io.IOException;
import java.util.List;

import com.eduMaster.core.courses;
import com.eduMaster.core.coursesDao;
import com.eduMaster.core.coursesDaoImpl;
import com.eduMaster.db.DatabaseConfig;
import com.eduMaster.db.MySqlDatabaseConnection;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 
 
@WebServlet("/courses") 
public class coursesservlet extends HttpServlet { 
    private static final long serialVersionUID = 1L; 
    private coursesDaoImpl coursesDao; 
 
    public void init() throws ServletException { 
        // Retrieve or construct DatabaseConfig with appropriate credentials 
        DatabaseConfig config = new DatabaseConfig("jdbc:mysql://localhost:3306/learnvesre", "ayat", "01145968321"); 
        MySqlDatabaseConnection dbConnection = new MySqlDatabaseConnection(config); 
        coursesDao = new coursesDaoImpl(dbConnection); 
    } 
 
    @Override 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
        String action = request.getParameter("action"); 
 
        if (action == null) { 
            action = ""; 
        } 
 
        switch (action) { 
            case "list": 
                listCourses(request, response); 
                break; 
            case "edit": 
                editCourse(request, response); 
                break; 
            case "delete": 
                deleteCourse(request, response); 
                break; 
            default: 
                listCourses(request, response); 
                break; 
        } 
    } 
 
    @Override 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
        String action = request.getParameter("action"); 
 
        if (action == null) { 
            action = ""; 
        } 
 
        switch (action) { 
            case "add": 
                deleteCourse(request, response); 
                break; 
            case "update": 
                editCourse(request, response); 
                break; 
            default: 
                break; 
        } 
    } 
 
    private void listCourses(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException { 
        try { 
            List<courses> coursesList = coursesDao.getAllCourses(); 
            System.out.println("Number of courses: " + coursesList.size()); 
            for (courses course : coursesList) { 
                System.out.println("Course ID: " + course.getCourseId()); 
                System.out.println("Title: " + course.getTitle()); 
                System.out.println("Description: " + course.getDescription()); 
            } 
            request.setAttribute("coursesList", coursesList); 
            RequestDispatcher dispatcher = request.getRequestDispatcher("courses.jsp"); 
            dispatcher.forward(request, response); 
        } catch (Exception e) { 
            // Log the exception 
            e.printStackTrace(); 
            // Set an error message 
            request.setAttribute("errorMessage", "Unexpected error occurred"); 
            // Add a redirect to the JSP page 
            response.sendRedirect("courses.jsp"); 
        } 
    } 
 
    private void editCourse(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException { 
        int course_id = Integer.parseInt(request.getParameter("course_id")); 
 
        courses course = coursesDao.getCourseById(course_id); 
 
        request.setAttribute("course", course); 
 
        request.getRequestDispatcher("editCourse.jsp").forward(request, response); }
 
    private void deleteCourse(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException { 
        int courses_id}