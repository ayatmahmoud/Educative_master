 package com.eduMaster.servlet;

import java.io.IOException;

import com.eduMaster.core.users;
import com.eduMaster.core.usersDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class usersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private usersDao usersDao;

    public void init() {
        usersDao = new usersDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int user_id = Integer.parseInt(request.getParameter("user_id"));
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        int phone_number = Integer.parseInt(request.getParameter("phone_number"));
        String first_name = request.getParameter("first_name");
        String last_name = request.getParameter("last_name");
        System.out.println("users: " + user_id + ", " + username + ", " + password + ", " + email + ", " + phone_number + ", " + first_name + ", " + last_name);
        users user = new users(user_id, username, password, email, phone_number, first_name, last_name);

        try {
        	System.out.println("Calling userDao.registerUser()"); 
            int result = usersDao.registerusers(user); 
            System.out.println("Result: " + result);
              // corrected method name and parameter
       } catch (Exception e) {
           e.printStackTrace();
       }

       response.sendRedirect("users.jsp");
   }

}