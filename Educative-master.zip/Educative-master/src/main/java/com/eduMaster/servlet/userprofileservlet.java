package com.eduMaster.servlet;


import java.io.IOException; 
import java.util.List;

import com.eduMaster.core.userprofile;
import com.eduMaster.core.userprofileDao; 
import com.eduMaster.core.userprofileDaoImpl; 
import com.eduMaster.db.DatabaseConfig; 
import com.eduMaster.db.MySqlDatabaseConnection; 
 
import jakarta.servlet.RequestDispatcher; 
import jakarta.servlet.ServletException; 
import jakarta.servlet.annotation.WebServlet; 
import jakarta.servlet.http.HttpServlet; 
import jakarta.servlet.http.HttpServletRequest; 
import jakarta.servlet.http.HttpServletResponse; 
 
@WebServlet("/userprofiles") 
public class userprofileservlet extends HttpServlet { 
    private static final long serialVersionUID = 1L; 
    private userprofileDao userprofileDao; 
 
    public void init() throws ServletException { 
        // Retrieve or construct DatabaseConfig with appropriate credentials 
        DatabaseConfig config = new DatabaseConfig("jdbc:mysql://localhost:3306/learnvesre", "ayat", "01145968321"); 
        MySqlDatabaseConnection dbConnection = new MySqlDatabaseConnection(config); 
        userprofileDao = new userprofileDaoImpl(dbConnection); 
    } 
 
    @Override 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
        try { 
            List<userprofile> userprofiles = userprofileDao.getAlluserprofiles(); 
            System.out.println("Number of userprofiles: " + userprofiles.size()); 
            for (userprofile userprofile : userprofiles) { 
                System.out.println("Profile ID: " + userprofile.getProfile_id()); 
                System.out.println("User ID: " + userprofile.getUser_id()); 
                System.out.println("Balance: " + userprofile.getBalance()); 
                System.out.println("LinkedIn Profile: " + userprofile.getLinkedin_profile()); 
            } 
            request.setAttribute("userprofiles", userprofiles); 
            RequestDispatcher dispatcher = request.getRequestDispatcher("userprofiles.jsp"); 
            dispatcher.forward(request, response); 
        } catch (Exception e) { 
            // Log the exception 
            e.printStackTrace(); 
            // Set an error message 
            request.setAttribute("errorMessage", "Unexpected error occurred"); 
            // Add a redirect to the JSP page 
            response.sendRedirect("userprofiles.jsp"); 
        } 
    } 
 
     

	@Override 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
        doGet(request, response); 
    } 
}