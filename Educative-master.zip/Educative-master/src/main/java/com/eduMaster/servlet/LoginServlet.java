 package com.eduMaster.servlet;

import java.io.IOException;
import java.util.List;

import com.eduMaster.core.users;
import com.eduMaster.core.usersDao;
import com.eduMaster.db.DatabaseConfig;
import com.eduMaster.db.MySqlDatabaseConnection;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet<usersDaoImpl> extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private usersDaoImpl userDao;

    public void init() throws ServletException {
        // Retrieve or construct DatabaseConfig with appropriate credentials
        DatabaseConfig config = new DatabaseConfig("jdbc:mysql://localhost:3306/learnvesre", "ayat", "01145968321");
        MySqlDatabaseConnection dbConnection = new MySqlDatabaseConnection(config);
        userDao = new usersDaoImpl(dbConnection);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            List<users> users = ((Object) userDao).getUsersByEmailAndPassword(email, password);

            if (users.isEmpty()) {
                request.setAttribute("errorMessage", "Invalid email or password");
                RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
                dispatcher.forward(request, response);
            } else {
                request.setAttribute("user", users.get(0));
                RequestDispatcher dispatcher = request.getRequestDispatcher("welcome.jsp");
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            // Log the exception
            e.printStackTrace();
            // Set an error message
            request.setAttribute("errorMessage", "Unexpected error occurred");
            // Add a redirect to the JSP page
            response.sendRedirect("login.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}