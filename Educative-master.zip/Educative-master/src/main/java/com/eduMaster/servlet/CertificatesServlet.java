 package com.eduMaster.servlet;

import java.io.IOException;
import java.security.cert.Certificate;
import java.util.UUID;

import com.eduMaster.core.CertificatesDao;
import com.eduMaster.core.certificates;
import com.eduMaster.core.enrollment;
import com.eduMaster.core.users;
import com.eduMaster.core.usersDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/certificates")
public class CertificatesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private usersDao userDao;
    private CertificatesDao certificateDao;

    @Override
    public void init() {
        usersDao usersDao = new usersDao();
        certificateDao = new CertificatesDao();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int userId = Integer.parseInt(request.getParameter("user_id"));
            int courseId = Integer.parseInt(request.getParameter("course_id"));
            Object users_id;
			users users = userDao.getuserByid(users_id);
            Object user_id;
			Object course_id;
			enrollment courseEnrollment = new enrollment(user_id, course_id);
            if (courseEnrollment.isCompleted()) {
                Certificate certificate = createCertificate(user, courseEnrollment);
                certificateDao.addCertificate(certificate);
                users.addCertificate(certificate);
                usersDao.updateUser(user);
            }
            response.sendRedirect("user_profile.jsp");
        } catch (NumberFormatException e) {
            // handle invalid user_id or course_id
        }
    }

    private Certificate createCertificate(users user, enrollment courseEnrollment) {
        String certificateUrl = generateCertificateUrl();
        return new certificates(user.getuser_id(), courseEnrollment.getCourseId(), certificateUrl);
    }

    private String generateCertificateUrl() {
        // Implement your logic to generate a unique certificate URL
        // For demonstration purposes, I'll return a dummy URL
        return "https://example.com/certificates/" + UUID.randomUUID().toString();
    }
}