package com.eduMaster.servlet;

import java.io.IOException;
import java.util.List;

import com.eduMaster.core.usercourses;
import com.eduMaster.core.usercoursesDao;
import com.eduMaster.core.usersDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 
 
@WebServlet("/user_courses") 
public class usercoursesServlet extends HttpServlet { 
    private static final long serialVersionUID = 1L; 
    private usercoursesDao usercoursesDao; 
    private usersDao usersDao; 
 
    public void init() { 
        usercoursesDao = new usercoursesDao); 
        usersDao = new usersDao(); 
    } 
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException { 
 
        int user_id = Integer.parseInt(request.getParameter("user_id")); 
        int course_id = Integer.parseInt(request.getParameter("course_id")); 
 
        System.out.println("user_id: " + user_id + ", course_id: " + course_id); 
 
        // create a new user_courses object 
		usercourses userCourse = new usercourses(0, user_id, course_id); 
		// add the user_courses relationship to the database 
		usercoursesDao.addusercourses(userCourse); 
		// get the updated list of courses for the user 
		List<Integer> courseIds = usersDao.getusercourses(user_id); 
		// store the updated list of courses in the user's session 
		request.getSession().setAttribute("courseIds", courseIds); 
		System.out.println("Added user_courses relationship to the database."); 
 
        response.sendRedirect("profile.jsp"); 
    } 
 
}