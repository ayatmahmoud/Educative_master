package com.eduMaster.core;

import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.time.LocalDate; 
import java.util.ArrayList; 
import java.util.List; 
 
import com.eduMaster.db.DatabaseConfig; 
import com.eduMaster.db.MySqlDatabaseConnection; 
 
public class EnrollmentDao { 
    private Connection connection; 
 
    public EnrollmentDao() { 
        DatabaseConfig config = new DatabaseConfig("jdbc:mysql://localhost:3306/learnvesre", "ayat", "01145968321"); 
        MySqlDatabaseConnection dbConnection = new MySqlDatabaseConnection(config); 
        connection = dbConnection.getConnection(); 
    } 
 
    // Get all enrollments 
    public List<enrollment> getAllEnrollments() { 
        List<enrollment> enrollmentsList = new ArrayList<>(); 
        String query = "SELECT * FROM enrollments"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            ResultSet resultSet = statement.executeQuery(); 
 
            while (resultSet.next()) { 
                int enrollmentId = resultSet.getInt("enrollment_id"); 
                int userId = resultSet.getInt("user_id"); 
                int courseId = resultSet.getInt("course_id"); 
                String enrollmentData = resultSet.getString("enrollment_date"); 
                LocalDate completionDate = resultSet.getDate("completion_date").toLocalDate(); 
                Integer certificateId = resultSet.getObject("certificate_id", Integer.class); 
 
                enrollment enrollment = new enrollment(enrollmentId, userId, courseId, enrollmentData, completionDate, certificateId); 
                enrollmentsList.add(enrollment); 
            } 
 
            resultSet.close(); 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
 
        return enrollmentsList; 
    } 
 
    // Get enrollment by ID 
    public enrollment getEnrollmentById(int enrollmentId) { 
        enrollment enrollment = null; 
        String query = "SELECT * FROM enrollments WHERE enrollment_id = ?"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setInt(1, enrollmentId); 
            ResultSet resultSet = statement.executeQuery(); 
 
            if (resultSet.next()) { 
                int userId = resultSet.getInt("user_id"); 
                int courseId = resultSet.getInt("course_id"); 
                String enrollmentData = resultSet.getString("enrollment_date"); 
                LocalDate completionDate = resultSet.getDate("completion_date").toLocalDate(); 
                Integer certificateId = resultSet.getObject("certificate_id", Integer.class); 
 
                enrollment = new enrollment(enrollmentId, userId, courseId, enrollmentData, completionDate, certificateId); 
            } 
 
            resultSet.close(); 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
    
        return enrollment; 
    }
 
    // Add a new enrollment 
    public void addEnrollment(enrollment enrollment) { 
        String query = "INSERT INTO enrollments (user_id, course_id, enrollment_data, completion_date, certificate_id) VALUES (?, ?, ?, ?, ?)"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setInt(1, enrollment.getUserId()); 
            statement.setInt(2, enrollment.getCourseId()); 
            statement.setString(3, enrollment.getEnrollment_date()); 
            statement.setDate(4, java.sql.Date.valueOf(enrollment.getCompletionDate()));}
