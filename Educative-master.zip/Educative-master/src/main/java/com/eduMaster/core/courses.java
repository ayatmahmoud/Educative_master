 package com.eduMaster.core; 
 public class courses{
// Course attributes 
private int course_id; 
private String title; 
private String description; 
 
 
public courses(int course_id, String title, String description) { 
    this.course_id = course_id; 
    this.title = title; 
    this.description = description; 
} 
 
// Getters 
public int getcourse_id() { 
    return course_id; 
} 
 
public String gettitle() { 
    return title; 
} 
 
public String getdescription() { 
    return description; 
} 
 
// Setters 
public void setCourse_id(int course_id) { 
    this.course_id = course_id; 
} 
 
public void setTitle(String title) { 
    this.title = title; 
} 
 
public void setDescription(String description) { 
    this.description = description; 
} 
 
// Getter methods for all attributes (camelCase naming convention) 
public int getCourseId() { 
    return course_id; 
} 
 
public String getTitle() { 
    return title; 
} 
 
public String getDescription() { 
    return description; 
}}