package com.eduMaster.core;

public class usercourses {
    private int user_course_id;
    private int user_id;
    private int course_id;

    public usercourses(int user_course_id, int user_id, int course_id) {
        this.user_course_id = user_course_id;
        this.user_id = user_id;
        this.course_id = course_id;
    }

    // Getters and setters
    public int getuser_course_id() {
        return user_course_id;
    }

    public void setuser_course_id(int user_course_id) {
        this.user_course_id = user_course_id;
    }

    public int getuser_id() {
        return user_id;
    }

    public void setuser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getcourse_id() {
        return course_id;
    }

    public void setcourse_id(int course_id) {
        this.course_id = course_id;
    }
}