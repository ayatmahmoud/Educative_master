package com.eduMaster.core;
 

public class userprofile {
    private int profile_id;
    private int user_id;
    private double balance;
    private String linkedin_profile;

    // Constructor
    public userprofile(int profile_id, int user_id, double balance, String linkedin_profile) {
        this.profile_id = profile_id;
        this.user_id = user_id;
        this.balance = balance;
        this.linkedin_profile = linkedin_profile;
    }

    // Getters
    public int getProfile_id() {
        return profile_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public double getBalance() {
        return balance;
    }

    public String getLinkedin_profile() {
        return linkedin_profile;
    }

    // Setters
    public void setProfile_id(int profile_id) {
        this.profile_id = profile_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void setLinkedin_profile(String linkedin_profile) {
        this.linkedin_profile = linkedin_profile;
    }
}
