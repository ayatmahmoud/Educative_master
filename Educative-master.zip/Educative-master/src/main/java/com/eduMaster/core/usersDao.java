 package com.eduMaster.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.catalina.User;

public class usersDao {

    public int registerusers(users user) throws ClassNotFoundException , SQLException{
    	
        String insertusersSql = "INSERT INTO users" +
            "  (user_id, username, password, email , phone_number, first_name, last_name) VALUES " +
            " (?, ?, ?, ?, ?, ?, ?);";

        int result = 0;

        Class.forName("com.mysql.cj.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/learnvesre", "ayat", "01145968321");

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(insertusersSql)) {
            preparedStatement.setInt(1, user.getuser_id());
            preparedStatement.setString(2, user.getusername());
            preparedStatement.setString(3, user.getpassword());
            preparedStatement.setString(4, user.getemail());
            preparedStatement.setInt(5, user.getphone_number());
            preparedStatement.setString(6, user.getfirst_name());
            preparedStatement.setString(7, user.getlast_name());

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return result;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

	public List<Integer> getusercourses(int user_id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateusers(User user) {
		// TODO Auto-generated method stub
		
	}

	public static User getuserById(Object users_id) {
		// TODO Auto-generated method stub
		return null;
	}
}
