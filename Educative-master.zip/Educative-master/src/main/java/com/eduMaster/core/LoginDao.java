 package com.eduMaster.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.eduMaster.core.Login;

public class LoginDao {

    public boolean authenticateUser(Login login) throws ClassNotFoundException {
        String SELECT_USER_SQL = "SELECT * FROM learnvesre.users;";
        boolean isValidUser = false;

        Class.forName("com.mysql.cj.jdbc.Driver");

        try (Connection connection = DriverManager
                .getConnection("jdbc:mysql://localhost:3306/learnvesre", "ayat", "01145968321");
                // Step 2: Create a statement using connection object
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_SQL)) {
            preparedStatement.setString(1, login.getEmail());
            preparedStatement.setString(2, login.getPassword());

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet resultSet = preparedStatement.executeQuery();
            isValidUser = resultSet.next();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return isValidUser;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
