package com.eduMaster.core;
import com.eduMaster.core.LoginDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDaoImpl implements  LoginDao {

    public boolean authenticateUser(String email, String password, Connection connection) {
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next(); // User exists if result set has at least one row
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}