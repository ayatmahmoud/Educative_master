 package com.eduMaster.core; 
 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.util.ArrayList; 
import java.util.List; 
 
public class usercoursesDaoImpl { 
 
    private Connection connection; 
 
    public usercoursesDaoImpl(Connection connection) { 
        this.connection = connection; 
    } 
 
    public void addUserCourse(usercourses userCourse) throws SQLException { 
        String sql = "INSERT INTO user_courses (user_id, course_id) VALUES (?, ?)"; 
        PreparedStatement statement = connection.prepareStatement(sql); 
        statement.setInt(1, userCourse.getuser_id()); 
        statement.setInt(2, userCourse.getcourse_id()); 
        statement.executeUpdate(); 
    } 
 
    public void removeUserCourse(int userCourseId) throws SQLException { 
        String sql = "DELETE FROM user_courses WHERE user_course_id = ?"; 
        PreparedStatement statement = connection.prepareStatement(sql); 
        statement.setInt(1, userCourseId); 
        statement.executeUpdate(); 
    } 
 
    public List<Integer> getUserCourses(int userId) throws SQLException { 
        String sql = "SELECT course_id FROM user_courses WHERE user_id = ?"; 
        PreparedStatement statement = connection.prepareStatement(sql); 
        statement.setInt(1, userId); 
        ResultSet resultSet = statement.executeQuery(); 
        List<Integer> courseIds = new ArrayList<>(); 
        while (resultSet.next()) { 
            courseIds.add(resultSet.getInt("course_id")); 
        } 
        return courseIds; 
    } 
 
    public void removeUserCourses(int userId) throws SQLException { 
        String sql = "DELETE FROM user_courses WHERE user_id = ?"; 
        PreparedStatement statement = connection.prepareStatement(sql); 
        statement.setInt(1, userId); 
        statement.executeUpdate(); 
    } 
}