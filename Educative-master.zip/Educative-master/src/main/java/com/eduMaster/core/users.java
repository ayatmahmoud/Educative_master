 package com.eduMaster.core;

public class users {
    private int user_id;
    private String username;
    private String password;
    private String email;
    private int phone_number;
    private String first_name;
    private String last_name;

    public users(int user_id, String username,String password, String email, int phone_number, String first_name,
            String last_name) {
        this.user_id = user_id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.phone_number = phone_number;
        this.password = password;
        this.first_name = first_name;
        this.last_name = last_name;
    }

    // Getters and setters for user_id
    public int getuser_id() {
        return user_id;
    }

    public void setuser_id(int user_id) {
        this.user_id = user_id;
    }

    // Getters and setters for username
    public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }
    // Getters and setters for password
    public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }
    // Getters and setters for email
    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }

    // Getters and setters for phoneNumber
    public int getphone_number() {
        return phone_number;
    }

    public void setphone_number(int phone_number) {
        this.phone_number = phone_number;
    }

    

    // Getters and setters for first_name
    public String getfirst_name() {
        return first_name;
    }

    public void setfirst_name(String first_name) {
        this.first_name = first_name;
    }

    // Getters and setters for last_name
    public String getlast_name() {
        return last_name;
    }

    public void setlast_name(String last_name) {
        this.last_name = last_name;
    }
}
