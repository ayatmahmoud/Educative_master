package com.eduMaster.core;

import java.util.List;

public interface userprofileDao { 
    void createuser(users newusers); 
    List<users> getAllusers(); 
    // Other methods for CRUD operations can be added here 
	void createusers(users newusers);
	void createuserprofile(userprofile newuserprofile);
	List<userprofile> getAlluserprofiles();
}

