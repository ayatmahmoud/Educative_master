 package com.eduMaster.core; 
 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.util.ArrayList; 
import java.util.List;

import com.eduMaster.db.MySqlDatabaseConnection; 
 
public class userprofileDaoImpl implements userprofileDao { 
    private MySqlDatabaseConnection connection; 
 
    public userprofileDaoImpl(MySqlDatabaseConnection dbConnection) { 
        this.connection = dbConnection; 
    } 
 
    @Override 
    public void createuserprofile(userprofile newuserprofile) { 
        String sql = "INSERT INTO userprofile (user_id, balance, linkedin_profile) VALUES (?, ?, ?)"; 
 
        try (PreparedStatement statement = connection.prepareStatement(sql)) { 
            statement.setInt(1, newuserprofile.getUser_id()); 
            statement.setDouble(2, newuserprofile.getBalance()); 
            statement.setString(3, newuserprofile.getLinkedin_profile()); 
 
            statement.executeUpdate(); 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
    } 
 
    public List<userprofile> getAlluserprofiles() { 
        String sql = "SELECT * FROM userprofile"; 
        List<userprofile> userprofiles = new ArrayList<>(); 
 
        try (PreparedStatement statement = connection.prepareStatement(sql); 
             ResultSet resultSet = statement.executeQuery()) { 
 
            while (resultSet.next()) { 
                int profile_id = resultSet.getInt("profile_id"); 
                int user_id = resultSet.getInt("user_id"); 
                double balance = resultSet.getDouble("balance"); 
                String linkedin_profile = resultSet.getString("linkedin_profile"); 
 
                userprofiles.add(new userprofile(profile_id, user_id, balance, linkedin_profile)); 
            } 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
 
        return userprofiles; 
    }

	@Override
	public void createuser(users newusers) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<users> getAllusers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createusers(users newusers) {
		// TODO Auto-generated method stub
		
	} 
 
    // Other methods for CRUD operations can be added here 
}