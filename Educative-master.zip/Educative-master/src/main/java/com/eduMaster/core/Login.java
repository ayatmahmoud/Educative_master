 package com.eduMaster.core;

import java.sql.Connection;

public class Login {
    // Login attributes
    private final String email;
    private final String password;

    // Private constructor to enforce use of the Builder
    private Login(Builder builder) {
        this.email = builder.email;
        this.password = builder.password;
    }

    // Getters for attributes (No setters to maintain immutability)
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    // Method to authenticate user (Simulated authentication logic)
    public boolean authenticate(Connection connection) {
        // Simulated authentication logic (replace with actual logic)
        return "user@example.com".equals(email) && "password123".equals(password);
    }

    // Builder class for constructing Login instances
    public static class Builder {
        private String email;
        private String password;

        public Builder() {
            // Set default values if needed
        }

        public Builder setEmail(String email) {
            this.email = email;
            return this;
        }

        public Builder setPassword(String password) {
            this.password = password;
            return this;
        }

        public Login build() {
            return new Login(this);
        }
    }

    // Example usage in a main method
    public static void main(String[] args) {
        // Create a Login instance using the Builder
        Login login = new Login.Builder()
                .setEmail("user@example.com")
                .setPassword("password123")
                .build();

        // Simulate authentication
        if (login.authenticate(null)) {
            System.out.println("Login successful");
        } else {
            System.out.println("Login failed");
        }
    }
}
