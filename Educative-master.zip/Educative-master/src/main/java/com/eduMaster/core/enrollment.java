package com.eduMaster.core;

import java.time.LocalDate;
public class enrollment{  private int enrollment_id;
    private int user_id;    private int courseId;
    private String enrollment_date;    private LocalDate completion_date;
    private Integer certificate_id;
	private int users_id;
    public enrollment(Object user_id2, Object course_id) {}
    public enrollment(int enrollmentId, int userId, int courseId, String enrollmentData, LocalDate completionDate, Integer certificateId) {        this.enrollment_id = enrollmentId;
        this.setUsers_id(userId);        this.courseId = courseId;
        this.setEnrollment_date(enrollmentData);        this.setCompletionDate(completionDate);
        this.setCertificate_id(certificateId);    }
    public int getEnrollmentId() {
        return enrollment_id;    }
    public void setEnrollmentId(int enrollmentId) {
        this.enrollment_id = enrollmentId;
    }
    public int getUserId() {        return user_id;
    }
    public void setUserId(int userId) {        this.user_id = userId;
    }
    public int getCourseId() {        return courseId;}
	public LocalDate getCompletionDate() {
		return completion_date;
	}
	public void setCompletionDate(LocalDate completionDate) {
		this.completion_date = completionDate;
	}
	public String getEnrollment_date() {
		return enrollment_date;
	}
	public void setEnrollment_date(String enrollment_date) {
		this.enrollment_date = enrollment_date;
	}
	public Integer getCertificate_id() {
		return certificate_id;
	}
	public void setCertificate_id(Integer certificate_id) {
		this.certificate_id = certificate_id;
	}
	public int getUsers_id() {
		return users_id;
	}
	public void setUsers_id(int users_id) {
		this.users_id = users_id;
	}}
