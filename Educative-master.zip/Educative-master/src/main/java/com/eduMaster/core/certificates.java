package com.eduMaster.core;

 
public class certificates {    
private int id;
private int user_id;    
private int courseId;
private String certificate_url;
private Object certificateUrl;
private int use_id;
private int course_id;
private int userId;
public certificates() {}
public certificates(int id, int user_id, int course_id, String certificate_url, Object certificateUrl) {        this.id = id;
    this.setUse_id(user_id);        this.setCourse_id(course_id);
    this.certificateUrl = certificateUrl;    }
public int getId() {
    return id;    }
public void setId(int id) {
    this.id = id;    }
public int getUserId() {
    return userId;    }
public void setUserId(int userId) {
    this.userId = userId;    }
public int getCourseId() {
    return courseId;    }
public void setCourseId(int courseId) {
    this.courseId = courseId;    }
public Object getCertificateUrl() {
    return certificateUrl;    }
public void setCertificateUrl(String certificateUrl) {
    this.certificateUrl = certificateUrl;    }
public int getUser_id() {
	return user_id;
}
public void setUser_id(int user_id) {
	this.user_id = user_id;
}
public String getCertificate_url() {
	return certificate_url;
}
public void setCertificate_url(String certificate_url) {
	this.certificate_url = certificate_url;
}
public int getUse_id() {
	return use_id;
}
public void setUse_id(int use_id) {
	this.use_id = use_id;
}
public int getCourse_id() {
	return course_id;
}
public void setCourse_id(int course_id) {
	this.course_id = course_id;
}
}