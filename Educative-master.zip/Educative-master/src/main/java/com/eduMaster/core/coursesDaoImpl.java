package com.eduMaster.core;
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.util.ArrayList; 
import java.util.List; 
 
import com.eduMaster.db.DatabaseConfig; 
import com.eduMaster.db.MySqlDatabaseConnection; 
 
public class coursesDaoImpl { 
    private Connection connection; 
 
    public coursesDaoImpl(MySqlDatabaseConnection dbConnection2) throws SQLException { 
        DatabaseConfig config = new DatabaseConfig("jdbc:mysql://localhost:3306/learnvesre", "ayat", "01145968321"); 
        MySqlDatabaseConnection dbConnection = new MySqlDatabaseConnection(config); 
        connection = dbConnection.getConnection(); 
    } 
 
    // Get all courses 
    public List<courses> getAllCourses() { 
        List<courses> coursesList = new ArrayList<>(); 
        String query = "SELECT * FROM courses"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            ResultSet resultSet = statement.executeQuery(); 
 
            while (resultSet.next()) { 
                int course_id = resultSet.getInt("course_id"); 
                String title = resultSet.getString("title"); 
                String description = resultSet.getString("description"); 
 
                courses course = new courses(course_id, title, description); 
                coursesList.add(course); 
            } 
 
            resultSet.close(); 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
 
        return coursesList; 
    } 
 
    // Get course by ID 
    public courses getCourseById(int course_id) { 
        courses course = null; 
        String query = "SELECT * FROM courses WHERE course_id = ?"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setInt(1, course_id); 
            ResultSet resultSet = statement.executeQuery(); 
 
            if (resultSet.next()) { 
                String title = resultSet.getString("title"); 
                String description = resultSet.getString("description"); 
 
                course = new courses(course_id, title, description); 
            } 
 
            resultSet.close(); 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
 
        return course; 
    } 
 
    // Add a new course 
    public void addCourse(courses course) { 
        String query = "INSERT INTO courses (title, description) VALUES (?, ?)"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setString(1, course.gettitle()); 
            statement.setString(2, course.getdescription()); 
 
            statement.executeUpdate(); 
 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
    } 
 
    // Update a course 
    public void updateCourse(courses course) { 
        String query = "UPDATE courses SET title = ?, description = ? WHERE course_id = ?"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setString(1, course.gettitle()); 
            statement.setString(2, course.getdescription()); 
            statement.setInt(3, course.getcourse_id()); 
 
            statement.executeUpdate(); 
 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
    } 
 
    // Delete a course 
    public void deleteCourse(int course_id) { 
        String query = "DELETE FROM courses WHERE course_id = ?"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setInt(1, course_id); 
 
            statement.executeUpdate(); 
 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
    } 
}
