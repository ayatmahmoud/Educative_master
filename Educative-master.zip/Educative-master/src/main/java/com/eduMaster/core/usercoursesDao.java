package com.eduMaster.core;

 

import java.util.List;

public interface usercoursesDao {
    
    usercourses createUsercourse(usercourses usercourse);

     
    List<usercourses> getAllUsercourses();

   
    usercourses getUsercourseById(int userCourseId);

  
    usercourses updateUsercourse(usercourses usercourse);


    boolean deleteUsercourse(int userCourseId);

	void addusercourses(usercourses userCourse);
}