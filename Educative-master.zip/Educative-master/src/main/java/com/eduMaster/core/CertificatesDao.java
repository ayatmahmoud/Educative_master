package com.eduMaster.core;

import java.security.cert.Certificate;
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.util.ArrayList;
import java.util.Collection;
import java.util.List; 
 
import com.eduMaster.db.DatabaseConfig; 
import com.eduMaster.db.MySqlDatabaseConnection; 
 
public class CertificatesDao { 
    private Connection connection; 
 
    public CertificatesDao() { 
        DatabaseConfig config = new DatabaseConfig("jdbc:mysql://localhost:3306/learnvesre", "ayat", "01145968321"); 
        MySqlDatabaseConnection dbConnection = new MySqlDatabaseConnection(config); 
        connection = dbConnection.getConnection(); 
    } 
 
    // Get all certificates 
    public List<Certificate> getAllCertificates() { 
        List<Certificate> certificatesList = new ArrayList<>(); 
        String query = "SELECT * FROM certificates"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            ResultSet resultSet = statement.executeQuery(); 
 
            while (resultSet.next()) { 
                int certificate_id = resultSet.getInt("certificate_id"); 
                int user_id = resultSet.getInt("user_id"); 
                int course_id = resultSet.getInt("course_id"); 
                String certificate_url = resultSet.getString("certificate_url"); 
 
                certificates certificate = new certificates(certificate_id, user_id, course_id, certificate_url, getAllCertificates()); 
                certificatesList.addAll((Collection<? extends Certificate>) certificate); 
            } 
 
            resultSet.close(); 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
 
        return certificatesList; 
    } 
 
    // Get certificate by ID 
    public certificates getCertificateById(int certificate_id) { 
        certificates certificate = null; 
        String query = "SELECT * FROM certificates WHERE certificate_id = ?"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setInt(1, certificate_id); 
            ResultSet resultSet = statement.executeQuery(); 
 
            if (resultSet.next()) { 
                int user_id = resultSet.getInt("user_id"); 
                int course_id = resultSet.getInt("course_id"); 
                String certificate_url = resultSet.getString("certificate_url"); 
 
                certificate = new certificates(certificate_id, user_id, course_id, certificate_url, certificate_url); 
            } 
 
            resultSet.close(); 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
 
        return certificate; 
    } 
 
    // Add a new certificate 
    public void addCertificate(Certificate certificate) { 
        String query = "INSERT INTO certificates (user_id, course_id, certificate_url) VALUES (?, ?, ?)"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setInt(1, certificate.getuser_id()); 
            statement.setInt(2, ((Object) certificate).getcourse_id()); 
            statement.setString(3, certificate.getCertificateUrl()); 
 
            statement.executeUpdate(); 
 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        } 
    } 
 
    // Update a certificate 
    public void updateCertificate(Certificate certificate) { 
        String query = "UPDATE certificates SET user_id = ?, course_id = ?, certificate_url = ? WHERE certificate_id = ?"; 
 
        try { 
            PreparedStatement statement = connection.prepareStatement(query); 
            statement.setInt(1, certificate.getcertificate_id()); 
            statement.setInt(2, certificate.getuser_id()); 
            statement.setInt(3, certificate.getcourse_id()); 
            statement.setString(4, certificate.getcertificate_Url()); 
             
 
            statement.executeUpdate(); 
 
            statement.close(); 
 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }