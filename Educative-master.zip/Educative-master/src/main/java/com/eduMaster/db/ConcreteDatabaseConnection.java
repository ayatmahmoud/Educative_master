package com.eduMaster.db;

 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConcreteDatabaseConnection implements DatabaseConnection {

    public Connection getConnection() throws SQLException {
        // Define database connection parameters
        String url = "jdbc:mysql://localhost:3306/learnvesre";
        String username = "ayat";
        String password = "01145968321";

        // Establish database connection
        Connection connection = DriverManager.getConnection(url, username, password);
        
        return connection;
    }
}
