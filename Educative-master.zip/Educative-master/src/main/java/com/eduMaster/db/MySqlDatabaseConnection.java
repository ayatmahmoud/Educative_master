package com.eduMaster.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



 
public class MySqlDatabaseConnection implements DatabaseConnection{
	
	private DatabaseConfig config;
	public MySqlDatabaseConnection(DatabaseConfig config) {
        this.config = config;
    }

    public Connection getConnection(DatabaseConfig config2) throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(config.getJdbcURL(), config.getJdbcUsername(), config.getJdbcPassword());
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL driver not found", e);
        }
    }

	public PreparedStatement prepareStatement(String sql) {
		// TODO Auto-generated method stub
		return null;
	}
}